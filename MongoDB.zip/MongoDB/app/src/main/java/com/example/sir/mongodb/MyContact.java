package com.example.sir.mongodb;

import java.util.Date;

/**
 * Created by sir on 3/13/2015.
 */
public class MyContact {

    public String first_name;
    public String street;
    public String phone;
    public String apt;
    public int np;
    public Date date;


}
